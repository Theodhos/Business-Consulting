/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, Mail, Phone, Clock, FileText } from 'lucide-react';
import { ContactMessage } from '../types';

interface ContactDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  prefilledMessage?: string;
}

export default function ContactDrawer({ isOpen, onClose, prefilledMessage }: ContactDrawerProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submissions, setSubmissions] = useState<ContactMessage[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    // Load existing messages
    const saved = localStorage.getItem('corient_messages');
    if (saved) {
      try {
        setSubmissions(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  useEffect(() => {
    if (prefilledMessage) {
      setFormData((prev) => ({ ...prev, message: prefilledMessage }));
    }
  }, [prefilledMessage]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      alert('Please fill out all required fields.');
      return;
    }

    const newMessage: ContactMessage = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      message: formData.message,
      createdAt: new Date().toLocaleString(),
    };

    const updated = [newMessage, ...submissions];
    setSubmissions(updated);
    localStorage.setItem('corient_messages', JSON.stringify(updated));

    setIsSubmitted(true);
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const handleReset = () => {
    setIsSubmitted(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
      />

      {/* Slide-in Drawer container */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 180 }}
          className="w-screen max-w-xl bg-[#090f14] text-white flex flex-col justify-between shadow-2xl border-l border-white/5"
        >
          {/* Header */}
          <div className="px-6 py-6 border-b border-white/5 flex items-center justify-between">
            <h2 className="text-xl font-serif tracking-wider text-white">
              Speak to a Partner
            </h2>
            <button
              id="contact-close-btn"
              onClick={onClose}
              className="p-2 -mr-2 hover:bg-white/5 rounded-full transition-colors text-white"
              aria-label="Close"
            >
              <X size={20} />
            </button>
          </div>

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto px-6 py-8 space-y-6">
            <p className="text-sm font-sans font-light tracking-wide text-white/70 leading-relaxed">
              There is no substitution for a personal conversation. If you are interested in hearing more about how we can help, please get in touch and one of our experts will contact you.
            </p>

            <AnimatePresence mode="wait">
              {!isSubmitted ? (
                <motion.form
                  key="contact-form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleSubmit}
                  className="space-y-5"
                >
                  {/* Name Input */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium tracking-wider text-white/60 uppercase">
                      Full Name *
                    </label>
                    <input
                      required
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="e.g. John Doe"
                      className="w-full bg-[#111a22] text-white px-4 py-3 rounded border border-white/5 focus:border-white/20 outline-none transition-all placeholder-white/20 text-sm"
                    />
                  </div>

                  {/* Email & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium tracking-wider text-white/60 uppercase">
                        Email Address *
                      </label>
                      <input
                        required
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="john@example.com"
                        className="w-full bg-[#111a22] text-white px-4 py-3 rounded border border-white/5 focus:border-white/20 outline-none transition-all placeholder-white/20 text-sm"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium tracking-wider text-white/60 uppercase">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="+27 82 123 4567"
                        className="w-full bg-[#111a22] text-white px-4 py-3 rounded border border-white/5 focus:border-white/20 outline-none transition-all placeholder-white/20 text-sm"
                      />
                    </div>
                  </div>

                  {/* Message */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium tracking-wider text-white/60 uppercase">
                      How can we help you? *
                    </label>
                    <textarea
                      required
                      rows={5}
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Describe your financial or wealth strategy needs..."
                      className="w-full bg-[#111a22] text-white px-4 py-3 rounded border border-white/5 focus:border-white/20 outline-none transition-all placeholder-white/20 text-sm resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    id="submit-contact-btn"
                    type="submit"
                    className="w-full py-4 bg-white text-black font-sans font-semibold text-xs tracking-widest rounded hover:bg-black hover:text-white hover:border hover:border-white border border-transparent transition-all duration-300 cursor-pointer uppercase"
                  >
                    Submit Request
                  </button>
                </motion.form>
              ) : (
                <motion.div
                  key="success-message"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="py-12 text-center space-y-6 bg-[#111a22] rounded-lg border border-white/5 p-6"
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/10 text-green-400 rounded-full">
                    <CheckCircle size={36} className="stroke-[1.5]" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-serif font-light tracking-wide">
                      Thank You
                    </h3>
                    <p className="text-sm text-white/70 leading-relaxed max-w-sm mx-auto">
                      Your request has been securely registered. A certified Corient Elite Partner will review your profile and reach out within 24 hours.
                    </p>
                  </div>
                  <button
                    id="reset-contact-btn"
                    onClick={handleReset}
                    className="px-6 py-2 border border-white/20 hover:border-white/60 text-white text-xs tracking-widest rounded uppercase transition-colors cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Expandable Submission History Log */}
            {submissions.length > 0 && (
              <div className="pt-6 border-t border-white/5">
                <button
                  id="toggle-history-btn"
                  onClick={() => setShowHistory(!showHistory)}
                  className="flex items-center gap-2 text-xs font-semibold tracking-wider text-white/40 hover:text-white transition-colors uppercase cursor-pointer"
                >
                  <FileText size={14} />
                  <span>{showHistory ? 'Hide' : 'Show'} Submission History ({submissions.length})</span>
                </button>

                <AnimatePresence>
                  {showHistory && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 space-y-3 overflow-hidden"
                    >
                      {submissions.map((msg) => (
                        <div key={msg.id} className="p-4 bg-[#111a22]/60 rounded border border-white/5 text-xs space-y-2">
                          <div className="flex justify-between items-center text-white/50">
                            <span className="font-medium text-white">{msg.name}</span>
                            <span className="flex items-center gap-1">
                              <Clock size={10} />
                              {msg.createdAt}
                            </span>
                          </div>
                          <div className="text-white/40 flex flex-col gap-1">
                            <span>Email: {msg.email}</span>
                            {msg.phone && <span>Phone: {msg.phone}</span>}
                          </div>
                          <p className="text-white/80 border-t border-white/5 pt-2 mt-2 font-light leading-relaxed">
                            {msg.message}
                          </p>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>

          {/* Quick Contacts Footer */}
          <div className="px-6 py-6 border-t border-white/5 bg-[#070b0e] grid grid-cols-2 gap-4 text-xs text-white/60">
            <div className="flex items-center gap-2">
              <Phone size={14} className="text-white/30" />
              <span>+27 11 900 8400</span>
            </div>
            <div className="flex items-center gap-2 justify-end">
              <Mail size={14} className="text-white/30" />
              <span>advisors@corient.co.za</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
