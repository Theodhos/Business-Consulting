/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Linkedin } from 'lucide-react';

interface FooterProps {
  onLinkClick: (section: 'services' | 'solutions' | 'partner' | 'contact') => void;
  onClientPortalClick: () => void;
}

export default function Footer({ onLinkClick, onClientPortalClick }: FooterProps) {
  return (
    <footer className="bg-[#05090c] text-white pt-16 pb-12 px-6 border-t border-white/5 font-sans relative z-10">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Footnote Disclosures requested in Image 4 & 5 */}
        <div className="space-y-4 text-xs text-white/50 font-light leading-relaxed max-w-4xl border-b border-white/5 pb-10">
          <p>
            There is no substitution for a personal conversation. If you are interested in hearing more about how we can help, please get in touch and one of our experts will contact you.
          </p>
          <p>
            As of 01/06/2026. Corient client assets and firm data reflect the aggregate figures of Corient Global HoldCo Limited ("HoldCo"). Data reflects varying as of dates due to differing reporting cycles.
          </p>
          <p>
            Corient refers to affiliated entities under common control of Corient Global HoldCo Limited.
          </p>
        </div>

        {/* Main Footer Links & Bio Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 pt-4">
          {/* Brand/Bio Column */}
          <div className="lg:col-span-5 space-y-6">
            <span className="text-2xl font-serif tracking-[0.25em] font-light uppercase text-white block">
              Corient
            </span>
            <p className="text-sm text-white/70 font-light leading-relaxed max-w-md">
              We put our clients' interests first. We focus on exceeding expectations, simplifying lives and helping establish lasting legacies.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full border border-white/10 hover:border-white/40 flex items-center justify-center text-white/60 hover:text-white transition-all hover:scale-105"
                aria-label="LinkedIn"
              >
                <Linkedin size={14} />
              </a>
            </div>
          </div>

          {/* Links Columns */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-8">
            {/* Column 1 */}
            <div className="space-y-4">
              <h4 className="text-xs font-semibold tracking-wider text-white/40 uppercase">About Us</h4>
              <ul className="space-y-3 text-sm">
                <li>
                  <button
                    onClick={() => onLinkClick('services')}
                    className="text-white/70 hover:text-white transition-colors cursor-pointer hover:underline underline-offset-4"
                  >
                    Wealth Strategy
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onLinkClick('services')}
                    className="text-white/70 hover:text-white transition-colors cursor-pointer hover:underline underline-offset-4"
                  >
                    Family Office Services
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 2 */}
            <div className="space-y-4">
              <h4 className="text-xs font-semibold tracking-wider text-white/40 uppercase">Who We Serve</h4>
              <ul className="space-y-3 text-sm">
                <li>
                  <button
                    onClick={() => onLinkClick('solutions')}
                    className="text-white/70 hover:text-white transition-colors cursor-pointer hover:underline underline-offset-4"
                  >
                    Insights
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onLinkClick('solutions')}
                    className="text-white/70 hover:text-white transition-colors cursor-pointer hover:underline underline-offset-4"
                  >
                    Global News
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3 */}
            <div className="space-y-4">
              <h4 className="text-xs font-semibold tracking-wider text-white/40 uppercase">Client Portal</h4>
              <ul className="space-y-3 text-sm">
                <li>
                  <button
                    onClick={onClientPortalClick}
                    className="text-white/70 hover:text-white transition-colors text-left cursor-pointer hover:underline underline-offset-4"
                  >
                    Secure Client Login
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => onLinkClick('contact')}
                    className="text-white/70 hover:text-white transition-colors text-left cursor-pointer hover:underline underline-offset-4"
                  >
                    Contact Us
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => alert('Our Locations: We have offices in Johannesburg, Cape Town, Sandton, London, and Munich.')}
                    className="text-white/70 hover:text-white transition-colors text-left cursor-pointer hover:underline underline-offset-4"
                  >
                    Our Locations
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Thick elegant horizontal line separating disclosures and copyright */}
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 text-xs text-white/50 font-light">
          {/* Legals Links */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-white/40">
            {['Disclosure', 'Terms of Use', 'Privacy', 'Accessibility', 'Site Map', 'Legal & Regulatory Information'].map((leg, index) => (
              <React.Fragment key={leg}>
                <a href={`#${leg.toLowerCase().replace(/\s+/g, '-')}`} className="hover:text-white transition-colors hover:underline">
                  {leg}
                </a>
                {index < 5 && <span className="text-white/10 font-normal">|</span>}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Very bottom line */}
        <div className="pt-4 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/40">
          <span>© 2026 Corient Holdings Inc. All rights reserved</span>
          
          <div className="flex items-center gap-2">
            <img
              src="https://flagcdn.com/w40/za.png"
              alt="South Africa"
              className="w-4 h-2.5 object-cover rounded-[1px] opacity-70"
              referrerPolicy="no-referrer"
            />
            <span className="font-light">South Africa (English)</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
