/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Menu, Search, X, Shield, Users, BarChart3, KeyRound, Award, Briefcase, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  onMenuClick: () => void;
  onMeetPartnerClick: () => void;
  onNavigate: (section: 'services' | 'solutions' | 'partner' | 'contact' | 'home' | 'about') => void;
  onPartnerSelect: (partnerName: string) => void;
}

interface SearchItem {
  type: 'service' | 'partner' | 'solution';
  title: string;
  subtitle: string;
  target: 'services' | 'solutions' | 'partner';
  partnerName?: string;
  icon: React.ComponentType<any>;
}

const searchableData: SearchItem[] = [
  { type: 'service', title: 'Family Office Services', subtitle: 'Consolidated accounting, wealth structuring, lifestyle administration', target: 'services', icon: Shield },
  { type: 'service', title: 'Wealth Strategy', subtitle: 'Bespoke assets, model portfolios, and absolute return alternative setups', target: 'services', icon: BarChart3 },
  { type: 'service', title: 'Trust & Estate Planning', subtitle: 'Cross-border fiduciary setups, offshore and local legacy transfers', target: 'services', icon: Users },
  { type: 'service', title: 'Corporate Advisory', subtitle: 'Business scale, balance sheet restructuring, pre-liquidity tax plans', target: 'services', icon: KeyRound },
  { type: 'partner', title: 'Adrian Vance', subtitle: 'Senior Managing Partner — Family Office Services expert', target: 'partner', partnerName: 'Adrian Vance', icon: Award },
  { type: 'partner', title: 'Evelyn Sterling', subtitle: 'Managing Director — Offshore and Global Wealth Strategy lead', target: 'partner', partnerName: 'Evelyn Sterling', icon: Award },
  { type: 'partner', title: 'Kofi Mensah', subtitle: 'Director — Corporate succession and business exit planner', target: 'partner', partnerName: 'Kofi Mensah', icon: Award },
  { type: 'solution', title: 'High-Net-Worth Advisory', subtitle: 'Strategic global asset allocations, risk protection matrices', target: 'solutions', icon: Briefcase },
  { type: 'solution', title: 'Business Owner Succession', subtitle: 'Bridging the gap between company assets and family estate structures', target: 'solutions', icon: Briefcase },
  { type: 'solution', title: 'Ultra-High-Net-Worth Office', subtitle: 'Institutional structures and sovereign trust portfolios exceeding $50M', target: 'solutions', icon: Briefcase },
];

export default function Navbar({
  onMenuClick,
  onMeetPartnerClick,
  onNavigate,
  onPartnerSelect,
}: NavbarProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Live filter search data
  const filteredResults = useMemo(() => {
    if (!searchQuery.trim()) return searchableData.slice(0, 4); // show featured first 4 if empty
    const query = searchQuery.toLowerCase();
    return searchableData.filter(
      (item) =>
        item.title.toLowerCase().includes(query) ||
        item.subtitle.toLowerCase().includes(query) ||
        item.type.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  const handleItemClick = (item: SearchItem) => {
    setIsSearchOpen(false);
    setSearchQuery('');
    if (item.target === 'partner' && item.partnerName) {
      onPartnerSelect(item.partnerName);
    } else {
      onNavigate(item.target);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-b from-black/75 to-transparent">
      <div className="max-w-7xl mx-auto px-6 h-20 md:h-24 flex items-center justify-between text-white font-sans">
        {/* Left Side: Menu Trigger */}
        <button
          id="nav-menu-btn"
          onClick={onMenuClick}
          className="flex items-center gap-2.5 hover:opacity-85 transition-all cursor-pointer group py-2"
          aria-label="Toggle Menu"
        >
          <Menu size={18} className="stroke-[1.5] group-hover:scale-110 transition-transform duration-300" />
          <span className="text-xs md:text-sm font-semibold tracking-[0.2em] uppercase">Menu</span>
        </button>

        {/* Center: Brand Name (Logo) */}
        <div className="absolute left-1/2 -translate-x-1/2 text-center pointer-events-auto">
          <a
            id="brand-logo"
            href="#"
            className="text-2xl md:text-3xl font-serif tracking-[0.3em] font-light hover:opacity-90 transition-opacity uppercase text-white"
          >
            Corient
          </a>
        </div>

        {/* Right Side: Options */}
        <div className="flex items-center gap-4 md:gap-6">
          {/* Language Selector */}
          <div className="flex items-center gap-2 text-xs font-semibold">
            <img
              src="https://flagcdn.com/w40/za.png"
              alt="South Africa Flag"
              className="w-4.5 h-3 object-cover rounded-[1px] shadow-sm"
              referrerPolicy="no-referrer"
            />
            <span className="tracking-[0.15em] uppercase text-white/80">EN</span>
          </div>

          {/* Search Trigger */}
          <button
            id="nav-search-btn"
            onClick={() => setIsSearchOpen(true)}
            className="p-2 hover:opacity-80 transition-all cursor-pointer bg-white/5 rounded-full hover:bg-white/10"
            aria-label="Search"
          >
            <Search size={15} className="stroke-[2.5]" />
          </button>

          {/* Meet a Partner Link */}
          <button
            id="nav-meet-partner-btn"
            onClick={onMeetPartnerClick}
            className="hidden sm:flex items-center gap-1.5 hover:opacity-85 transition-all cursor-pointer py-2 text-xs font-semibold tracking-[0.2em] uppercase"
          >
            <span className="relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1px] after:bg-white after:scale-x-0 hover:after:scale-x-100 after:origin-bottom-left after:transition-transform">
              Meet a Partner
            </span>
          </button>
        </div>
      </div>

      {/* Decorative Thin Horizontal Line */}
      <div className="w-full px-6 max-w-7xl mx-auto">
        <div className="border-b border-white/10 w-full"></div>
      </div>

      {/* Full-width Search Overlay */}
      <AnimatePresence>
        {isSearchOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col items-center justify-start pt-20 px-6 font-sans text-white overflow-y-auto"
          >
            <div className="w-full max-w-3xl flex flex-col space-y-6">
              {/* Top Row: Title & Close Button */}
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-white/40 uppercase">
                  Fiduciary Search Engine
                </span>
                <button
                  onClick={() => {
                    setIsSearchOpen(false);
                    setSearchQuery('');
                  }}
                  className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/70 hover:text-white"
                  aria-label="Close search"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Input Bar */}
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={20} />
                <input
                  autoFocus
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search wealth services, elite partners, strategies..."
                  className="w-full bg-[#111a22] text-white pl-14 pr-4 py-4 rounded-xl outline-none border border-white/10 focus:border-white/30 transition-all font-sans text-sm md:text-base placeholder-white/30 shadow-inner"
                />
              </div>

              {/* Live Matching Results Pane */}
              <div className="space-y-4 pt-4 pb-20">
                <span className="text-xs font-semibold tracking-wider text-white/40 uppercase">
                  {searchQuery.trim() ? `Search Results (${filteredResults.length})` : 'Featured Insights & Services'}
                </span>

                {filteredResults.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredResults.map((item, idx) => {
                      const IconComponent = item.icon;
                      return (
                        <motion.button
                          key={idx}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.04 }}
                          onClick={() => handleItemClick(item)}
                          className="p-4 rounded-xl bg-[#111a22]/60 hover:bg-[#111a22] border border-white/5 hover:border-white/20 text-left transition-all group flex items-start gap-4 cursor-pointer"
                        >
                          <div className="w-10 h-10 rounded-lg bg-white/5 group-hover:bg-white/15 flex items-center justify-center border border-white/10 text-white/80 group-hover:text-white transition-colors shrink-0">
                            <IconComponent size={18} className="stroke-[1.5]" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-serif text-sm font-medium text-white group-hover:text-white/80 transition-colors truncate">
                                {item.title}
                              </span>
                              <ArrowUpRight size={14} className="text-white/20 group-hover:text-white/70 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all shrink-0" />
                            </div>
                            <span className="text-[11px] text-white/50 group-hover:text-white/70 font-light mt-1 block leading-normal line-clamp-2">
                              {item.subtitle}
                            </span>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="py-12 text-center bg-[#111a22]/20 rounded-xl border border-white/5">
                    <p className="text-sm text-white/40 font-light">
                      No matching services or partners found. Try searching for "Evelyn", "Succession", or "Strategy".
                    </p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
