/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, ChevronRight } from 'lucide-react';
import { Slide } from '../types';

interface HeroSliderProps {
  onActionClick: (type: 'services' | 'solutions' | 'partner') => void;
}

const slidesData: Slide[] = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1508873696983-2df519f0397e?auto=format&fit=crop&w=2400&q=85',
    title: 'Redefining Wealth Management',
    subtitle: 'At Corient, we deliberately structured our partnership model to mitigate the conflicts inherent to most wealth management firms, foster true collaboration and deliver excellence. Our Partners operate as a unified team with one shared goal—to deliver the best of the firm to every client, at every interaction.',
    buttonText: 'DISCOVER OUR SERVICES',
    actionType: 'services',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1505245208761-ba872912fac0?auto=format&fit=crop&w=2400&q=85',
    title: 'Real wealth requires real solutions',
    subtitle: 'At Corient, we are breaking down the barriers that stand in the way of true collaboration.',
    buttonText: 'EXPLORE OUR SOLUTIONS',
    actionType: 'solutions',
    stats: [
      { value: 'US$508 billion', label: 'IN CLIENT ASSETS' },
      { value: '300+', label: 'PARTNERS' },
    ],
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1541447271487-09612b3f49f7?auto=format&fit=crop&w=2400&q=85',
    title: 'Meet a Partner',
    subtitle: 'At Corient, we empower our client relationship managers to bring the best of the firm to every client interaction.',
    buttonText: 'MEET A PARTNER',
    actionType: 'partner',
    stats: [
      { value: 'US$49.7 billion', label: 'IN CLIENT ASSETS' },
      { value: '99+', label: 'PARTNERS' },
    ],
  },
];

/* Helper Component: Smoothly Counts Up Stats inside Slides */
interface AnimatedStatCounterProps {
  value: string;
}

function AnimatedStatCounter({ value }: AnimatedStatCounterProps) {
  const [displayValue, setDisplayValue] = useState('');

  useEffect(() => {
    const numberPattern = /([0-9.,]+)/;
    const match = value.match(numberPattern);
    if (!match) {
      setDisplayValue(value);
      return;
    }

    const numStr = match[1];
    const numVal = parseFloat(numStr.replace(/,/g, ''));
    const prefix = value.substring(0, value.indexOf(numStr));
    const suffix = value.substring(value.indexOf(numStr) + numStr.length);

    let start = 0;
    const duration = 1400; // ms
    const startTime = performance.now();

    let animFrame: number;

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Cubic ease-out
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      const currentVal = start + (numVal - start) * easeProgress;

      let formattedNum = '';
      if (numStr.includes('.')) {
        formattedNum = currentVal.toFixed(1);
      } else {
        formattedNum = Math.floor(currentVal).toLocaleString();
      }

      setDisplayValue(`${prefix}${formattedNum}${suffix}`);

      if (progress < 1) {
        animFrame = requestAnimationFrame(animate);
      }
    };

    animFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animFrame);
  }, [value]);

  return <span>{displayValue}</span>;
}

export default function HeroSlider({ onActionClick }: HeroSliderProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeTooltip, setActiveTooltip] = useState<number | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const currentIdxRef = useRef(currentIdx);
  const lastTransitionRef = useRef(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Sync index ref
  useEffect(() => {
    currentIdxRef.current = currentIdx;
  }, [currentIdx]);

  // Automatic slide rotation
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentIdx((prev) => (prev + 1) % slidesData.length);
      }, 9500);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying]);

  // Scroll detection logic - INTERCEPTS page scroll to transition slides first
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let touchStartY = 0;

    const handleWheel = (e: WheelEvent) => {
      const isAtTop = window.scrollY < 15;
      if (!isAtTop) return;

      const now = Date.now();
      const throttleDelay = 1100; // time to let current slide animation settle

      if (now - lastTransitionRef.current < throttleDelay) {
        // Prevent default browser scrolling while in the lock-out period
        if (currentIdxRef.current < slidesData.length - 1 && e.deltaY > 0) {
          e.preventDefault();
        }
        if (currentIdxRef.current > 0 && e.deltaY < 0) {
          e.preventDefault();
        }
        return;
      }

      if (e.deltaY > 20) {
        // User scrolls DOWN
        if (currentIdxRef.current < slidesData.length - 1) {
          e.preventDefault();
          lastTransitionRef.current = now;
          setCurrentIdx((prev) => prev + 1);
        }
      } else if (e.deltaY < -20) {
        // User scrolls UP
        if (currentIdxRef.current > 0) {
          e.preventDefault();
          lastTransitionRef.current = now;
          setCurrentIdx((prev) => prev - 1);
        }
      }
    };

    const handleTouchStart = (e: TouchEvent) => {
      touchStartY = e.touches[0].clientY;
    };

    const handleTouchMove = (e: TouchEvent) => {
      const isAtTop = window.scrollY < 15;
      if (!isAtTop) return;

      const touchEndY = e.touches[0].clientY;
      const deltaY = touchStartY - touchEndY; // positive = swipe up (scroll down)
      const now = Date.now();
      const throttleDelay = 1100;

      if (now - lastTransitionRef.current < throttleDelay) {
        if (currentIdxRef.current < slidesData.length - 1 && deltaY > 15) {
          e.preventDefault();
        }
        if (currentIdxRef.current > 0 && deltaY < -15) {
          e.preventDefault();
        }
        return;
      }

      if (deltaY > 40) {
        // Swiped UP -> Next slide
        if (currentIdxRef.current < slidesData.length - 1) {
          e.preventDefault();
          lastTransitionRef.current = now;
          setCurrentIdx((prev) => prev + 1);
        }
      } else if (deltaY < -40) {
        // Swiped DOWN -> Previous slide
        if (currentIdxRef.current > 0) {
          e.preventDefault();
          lastTransitionRef.current = now;
          setCurrentIdx((prev) => prev - 1);
        }
      }
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    container.addEventListener('touchstart', handleTouchStart, { passive: true });
    container.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      container.removeEventListener('wheel', handleWheel);
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
    };
  }, []);

  const handleDotClick = (idx: number) => {
    setCurrentIdx(idx);
    lastTransitionRef.current = Date.now();
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const currentSlide = slidesData[currentIdx];

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[95vh] md:h-screen bg-[#04080b] overflow-hidden select-none"
    >
      {/* Background Slideshow with Parallax & Ken Burns zoom effect */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide.id}
            initial={{ opacity: 0, scale: 1.15, rotate: 0.01 }}
            animate={{ 
              opacity: 1, 
              scale: 1.05,
              transition: { duration: 1.6, ease: [0.16, 1, 0.3, 1] } 
            }}
            exit={{ 
              opacity: 0, 
              scale: 1, 
              transition: { duration: 0.8, ease: 'easeInOut' } 
            }}
            className="absolute inset-0 w-full h-full"
          >
            {/* Elegant luxury overlays for cinematic contrast */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#05090c] via-[#05090c]/40 to-black/75 z-10" />
            <div className="absolute inset-0 bg-radial-gradient from-transparent via-[#05090c]/25 to-[#05090c]/90 z-10" />
            
            <img
              src={currentSlide.image}
              alt={currentSlide.title}
              className="w-full h-full object-cover object-center"
              referrerPolicy="no-referrer"
            />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Luxury Ambient Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-white/[0.02] rounded-full blur-[120px] pointer-events-none z-10" />

      {/* Main Content Area */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 h-full flex flex-col justify-center items-center text-center text-white">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide.id}
            initial="hidden"
            animate="visible"
            exit="exit"
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: { staggerChildren: 0.15 },
              },
              exit: {
                opacity: 0,
                transition: { duration: 0.4 },
              },
            }}
            className="w-full max-w-4xl flex flex-col items-center pt-16 md:pt-24"
          >
            {/* Category Tag */}
            <motion.div
              variants={{
                hidden: { opacity: 0, y: 15 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
              }}
              className="mb-4 flex items-center gap-2"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              <span className="text-[10px] md:text-xs font-sans font-semibold tracking-[0.3em] text-white/50 uppercase">
                {currentSlide.id === 1 ? 'Partnership Fiduciary' : currentSlide.id === 2 ? 'Global Scale' : 'Advisory Match'}
              </span>
            </motion.div>

            {/* Title with sleek serif display font */}
            <motion.h1
              variants={{
                hidden: { opacity: 0, y: 35 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1] } },
              }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-light tracking-wide leading-[1.12] max-w-3xl mb-6 md:mb-8 text-shadow-lg"
            >
              {currentSlide.title}
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              variants={{
                hidden: { opacity: 0, y: 25 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1] } },
              }}
              className="text-sm sm:text-base md:text-lg font-sans font-light tracking-wide text-white/70 leading-relaxed max-w-3xl mb-8 md:mb-12 px-4"
            >
              {currentSlide.subtitle}
            </motion.p>

            {/* Premium Button with Elegant Hover effects */}
            <motion.div
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
              }}
              className="mb-12 md:mb-16"
            >
              <button
                id={`slide-btn-${currentSlide.id}`}
                onClick={() => onActionClick(currentSlide.actionType)}
                className="group relative px-10 py-4 bg-white text-black font-sans font-semibold text-xs tracking-[0.2em] rounded-full hover:bg-black hover:text-white border border-white transition-all duration-500 shadow-xl hover:shadow-2xl hover:scale-105 cursor-pointer flex items-center gap-2"
              >
                <span>{currentSlide.buttonText}</span>
                <ChevronRight size={14} className="group-hover:translate-x-1.5 transition-transform duration-300" />
              </button>
            </motion.div>

            {/* Elegant Fiduciary Statistics Counter Display (Slide 2 & 3 only) */}
            {currentSlide.stats && (
              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 25 },
                  visible: { opacity: 1, y: 0, transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.25 } },
                }}
                className="grid grid-cols-2 gap-12 sm:gap-24 text-center mt-4 w-full max-w-2xl px-8 py-6 rounded-2xl bg-[#05090c]/30 backdrop-blur-md border border-white/5"
              >
                {currentSlide.stats.map((stat, sIdx) => (
                  <div key={sIdx} className="flex flex-col items-center">
                    <span className="text-3xl sm:text-4xl md:text-5xl font-serif font-light tracking-wide mb-2 text-white/95">
                      <AnimatedStatCounter value={stat.value} />
                    </span>
                    <span className="text-[10px] sm:text-xs font-sans font-semibold tracking-[0.22em] text-white/50 uppercase">
                      {stat.label}
                    </span>
                  </div>
                ))}
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Left side Indicators (Vertical Progress dots + Tooltips + Play/Pause) */}
      <div className="absolute left-6 md:left-10 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-8">
        {/* Progress Dots with Premium Hover Tooltips */}
        <div className="flex flex-col items-center gap-6">
          {slidesData.map((slide, idx) => {
            const isActive = idx === currentIdx;
            return (
              <div 
                key={slide.id} 
                className="relative flex items-center"
                onMouseEnter={() => setActiveTooltip(idx)}
                onMouseLeave={() => setActiveTooltip(null)}
              >
                {/* Hover Tooltip */}
                <AnimatePresence>
                  {activeTooltip === idx && (
                    <motion.div
                      initial={{ opacity: 0, x: -15 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -15 }}
                      className="absolute left-10 py-1.5 px-3 bg-black/90 border border-white/10 rounded text-[10px] font-sans font-semibold tracking-wider text-white uppercase whitespace-nowrap pointer-events-none shadow-2xl"
                    >
                      {slide.id === 1 ? 'Overview' : slide.id === 2 ? 'Solutions' : 'Partner Match'}
                    </motion.div>
                  )}
                </AnimatePresence>

                <button
                  id={`slider-dot-${idx}`}
                  onClick={() => handleDotClick(idx)}
                  className="relative flex items-center justify-center w-6 h-6 group cursor-pointer"
                  aria-label={`Go to slide ${idx + 1}`}
                >
                  {/* Active circle outline springing animation */}
                  {isActive && (
                    <motion.div
                      layoutId="activeSlideIndicator"
                      className="absolute inset-0 border border-white/60 rounded-full"
                      transition={{ type: 'spring', stiffness: 180, damping: 22 }}
                    />
                  )}
                  {/* Inner interactive dot */}
                  <div
                    className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${
                      isActive ? 'bg-white scale-125' : 'bg-white/30 group-hover:bg-white/80'
                    }`}
                  />
                </button>
              </div>
            );
          })}
        </div>

        {/* Play/Pause Button */}
        <button
          id="slider-play-pause-btn"
          onClick={togglePlayPause}
          className="w-10 h-10 border border-white/10 hover:border-white/40 bg-[#05090c]/40 hover:bg-[#05090c]/80 rounded-full flex items-center justify-center text-white/70 hover:text-white transition-all cursor-pointer group mt-2 shadow-md"
          aria-label={isPlaying ? 'Pause Slideshow' : 'Play Slideshow'}
        >
          {isPlaying ? (
            <Pause size={12} className="group-hover:scale-105 transition-transform" />
          ) : (
            <Play size={12} className="translate-x-[1px] group-hover:scale-105 transition-transform" />
          )}
        </button>
      </div>

      {/* Bottom Luxury Mouse Wheel Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-3 pointer-events-none opacity-60 hover:opacity-100 transition-opacity">
        <span className="text-[9px] md:text-[10px] font-sans font-semibold tracking-[0.3em] text-white/40 uppercase">
          {currentIdx === slidesData.length - 1 ? 'Scroll to Speak to a Partner' : 'Scroll to Transition Slide'}
        </span>
        <div className="w-6 h-10 border border-white/20 rounded-full flex justify-center p-1.5">
          <motion.div
            animate={{
              y: [0, 10, 0],
            }}
            transition={{
              duration: 1.6,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="w-1.5 h-1.5 bg-white/70 rounded-full"
          />
        </div>
      </div>
    </div>
  );
}
