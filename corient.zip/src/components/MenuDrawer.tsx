/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { X, ArrowRight, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (section: 'services' | 'solutions' | 'partner' | 'contact' | 'home' | 'about') => void;
}

export default function MenuDrawer({ isOpen, onClose, onNavigate }: MenuDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
      />

      {/* Drawer Container */}
      <div className="absolute inset-y-0 left-0 max-w-full flex">
        <motion.div
          initial={{ x: '-100%' }}
          animate={{ x: 0 }}
          exit={{ x: '-100%' }}
          transition={{ type: 'tween', duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="w-screen max-w-md bg-[#090f14] text-white flex flex-col justify-between shadow-2xl relative"
        >
          {/* Drawer Header */}
          <div className="px-6 py-6 border-b border-white/5 flex items-center justify-between">
            <span className="text-xl font-serif tracking-[0.2em] uppercase text-white">
              Corient
            </span>
            <button
              id="menu-close-btn"
              onClick={onClose}
              className="p-2 -mr-2 hover:bg-white/5 rounded-full transition-colors text-white"
              aria-label="Close menu"
            >
              <X size={20} />
            </button>
          </div>

          {/* Drawer Links */}
          <div className="flex-1 overflow-y-auto px-6 py-8 space-y-8">
            <nav className="space-y-4">
              <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-white/40 block uppercase">
                Navigation
              </span>

              <div className="space-y-2">
                {[
                  { label: 'Home', action: 'home' },
                  { label: 'Our Services', action: 'services' },
                  { label: 'Custom Solutions', action: 'solutions' },
                  { label: 'Meet a Partner', action: 'partner' },
                  { label: 'Speak to a Partner', action: 'contact' },
                ].map((item) => (
                  <button
                    key={item.label}
                    id={`menu-item-${item.action}`}
                    onClick={() => {
                      onNavigate(item.action as any);
                      onClose();
                    }}
                    className="flex items-center justify-between w-full py-2.5 text-left text-lg md:text-xl font-serif font-light hover:text-white/70 transition-all group cursor-pointer"
                  >
                    <span>{item.label}</span>
                    <ArrowRight size={16} className="opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
                  </button>
                ))}
              </div>
            </nav>

            {/* Quick Links / Resources */}
            <div className="space-y-4">
              <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-white/40 block uppercase">
                Client Resources
              </span>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <a
                  href="#client-portal"
                  onClick={() => {
                    alert('Client Portal: Redirecting to secure login interface... (Simulated secure partner authentication portal)');
                    onClose();
                  }}
                  className="bg-[#111a22] hover:bg-[#16232d] px-4 py-3 rounded border border-white/5 text-center transition-colors font-medium text-xs tracking-wider uppercase"
                >
                  Client Portal
                </a>
                <button
                  onClick={() => {
                    onNavigate('contact');
                    onClose();
                  }}
                  className="bg-[#111a22] hover:bg-[#16232d] px-4 py-3 rounded border border-white/5 text-center transition-colors font-medium text-xs tracking-wider uppercase cursor-pointer"
                >
                  Contact Us
                </button>
              </div>
            </div>

            {/* Contact details */}
            <div className="pt-4 border-t border-white/5 space-y-4 text-sm text-white/70">
              <div className="flex items-start gap-3">
                <MapPin size={16} className="text-white/40 mt-0.5 shrink-0" />
                <span>Johannesburg Office, Sandton City, South Africa</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone size={16} className="text-white/40 shrink-0" />
                <span>+27 11 900 8400</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={16} className="text-white/40 shrink-0" />
                <span>advisors@corient.co.za</span>
              </div>
            </div>
          </div>

          {/* Drawer Footer */}
          <div className="px-6 py-6 border-t border-white/5 bg-[#070b0e] flex items-center justify-between text-xs text-white/40">
            <span>© 2026 Corient Holdings Inc.</span>
            <div className="flex items-center gap-4">
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={16} />
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
