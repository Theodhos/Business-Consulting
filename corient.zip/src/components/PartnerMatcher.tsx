/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronRight, ChevronLeft, Check, Award, MapPin, Briefcase, ChevronRightSquare } from 'lucide-react';
import { Partner } from '../types';

interface PartnerMatcherProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPartner: (partnerName: string) => void;
}

const partnersData: Partner[] = [
  {
    id: 'p1',
    name: 'Adrian Vance',
    role: 'Senior Managing Partner, Family Office Services',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    specialty: ['Generational Wealth', 'Estate Planning', 'Trust Administration'],
    bio: 'Adrian has over 22 years of experience managing complex multi-generational family office arrangements for South Africa\'s most prominent families. He specializes in asset protection and cross-border governance.',
    location: 'Johannesburg Office',
    experience: '22+ Years Experience',
  },
  {
    id: 'p2',
    name: 'Evelyn Sterling',
    role: 'Managing Director, Global Wealth Strategy',
    photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
    specialty: ['Global Assets', 'Offshore Investment', 'Wealth Growth'],
    bio: 'Evelyn advises high-net-worth individuals on offshore structuring, currency hedging, and bespoke global equity portfolios. Her client focus centers on customized risk-adjusted growth.',
    location: 'Cape Town & London',
    experience: '18+ Years Experience',
  },
  {
    id: 'p3',
    name: 'Kofi Mensah',
    role: 'Director, Business Succession & Tax Strategy',
    photo: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=600&q=80',
    specialty: ['Business Succession', 'Tax Optimization', 'Corporate Structuring'],
    bio: 'Kofi specializes in helping entrepreneurs and executives restructure, scale, and successfully exit their businesses, maximizing tax efficiency and securing long-term family security.',
    location: 'Sandton Office',
    experience: '15+ Years Experience',
  },
];

export default function PartnerMatcher({ isOpen, onClose, onSelectPartner }: PartnerMatcherProps) {
  const [step, setStep] = useState(1);
  const [goal, setGoal] = useState('');
  const [assets, setAssets] = useState('');
  const [location, setLocation] = useState('');
  const [matchedPartner, setMatchedPartner] = useState<Partner | null>(null);

  const handleNext = () => {
    if (step === 3) {
      // Calculate matching algorithm based on options
      let match = partnersData[0]; // default
      if (goal === 'business' || assets === 'uhnw') {
        match = partnersData[2]; // Kofi Mensah
      } else if (goal === 'global' || location === 'intl') {
        match = partnersData[1]; // Evelyn Sterling
      } else {
        match = partnersData[0]; // Adrian Vance
      }
      setMatchedPartner(match);
      setStep(4);
    } else {
      setStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setStep((prev) => prev - 1);
  };

  const handleReset = () => {
    setStep(1);
    setGoal('');
    setAssets('');
    setLocation('');
    setMatchedPartner(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-xs transition-opacity"
      />

      {/* Center Modal Container */}
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="w-full max-w-2xl bg-[#090f14] border border-white/5 text-white rounded-xl shadow-2xl flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-white/5 flex items-center justify-between">
            <h2 className="text-lg font-serif tracking-wider text-white flex items-center gap-2">
              <Award size={18} className="text-white/75" />
              <span>Meet a Corient Partner</span>
            </h2>
            <button
              id="matcher-close-btn"
              onClick={onClose}
              className="p-2 -mr-2 hover:bg-white/5 rounded-full transition-colors text-white"
              aria-label="Close"
            >
              <X size={20} />
            </button>
          </div>

          {/* Body Content */}
          <div className="flex-1 px-6 py-8 md:px-10 overflow-y-auto min-h-[350px] max-h-[75vh]">
            {/* Steps Progress Indicator */}
            {step < 4 && (
              <div className="flex items-center justify-between mb-8 max-w-md mx-auto">
                {[1, 2, 3].map((s) => (
                  <React.Fragment key={s}>
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold ${
                          step >= s ? 'bg-white text-black' : 'border border-white/20 text-white/40'
                        }`}
                      >
                        {step > s ? <Check size={12} className="stroke-[3]" /> : s}
                      </div>
                      <span className={`text-[11px] font-semibold tracking-wider uppercase hidden sm:inline ${
                        step === s ? 'text-white' : 'text-white/40'
                      }`}>
                        {s === 1 ? 'Goals' : s === 2 ? 'Capital' : 'Region'}
                      </span>
                    </div>
                    {s < 3 && <div className={`flex-1 h-[1px] mx-3 ${step > s ? 'bg-white' : 'bg-white/10'}`} />}
                  </React.Fragment>
                ))}
              </div>
            )}

            <AnimatePresence mode="wait">
              {/* Step 1: Goals */}
              {step === 1 && (
                <motion.div
                  key="step-1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center space-y-2 mb-6">
                    <h3 className="text-xl font-serif text-white">What is your primary financial focus?</h3>
                    <p className="text-xs text-white/50">Select the area where you require immediate professional advice.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-3 max-w-lg mx-auto">
                    {[
                      { id: 'family', label: 'Family Office Services & Estate Planning', desc: 'Preserving generational wealth and establishing structured legal arrangements.' },
                      { id: 'global', label: 'Bespoke Global Assets & Investment Growth', desc: 'Offshore diversification, asset growth, and custom equity solutions.' },
                      { id: 'business', label: 'Business Succession & Tax Strategy', desc: 'Scaling operations, corporate restructuring, and planning a clean business transition.' },
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        onClick={() => setGoal(opt.id)}
                        className={`w-full p-4 rounded text-left border transition-all hover:bg-white/[0.02] cursor-pointer ${
                          goal === opt.id ? 'border-white bg-white/[0.03]' : 'border-white/10 bg-transparent'
                        }`}
                      >
                        <span className="font-serif text-sm block font-medium mb-1">{opt.label}</span>
                        <span className="text-xs text-white/40 font-light block">{opt.desc}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Step 2: Assets */}
              {step === 2 && (
                <motion.div
                  key="step-2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center space-y-2 mb-6">
                    <h3 className="text-xl font-serif text-white">What is your investable asset level?</h3>
                    <p className="text-xs text-white/50">This helps us match you with partner directors with appropriate account profiles.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-3 max-w-lg mx-auto">
                    {[
                      { id: 'affluent', label: 'Under US$2 Million', desc: 'Standard wealth advice, retirement positioning, portfolio setup.' },
                      { id: 'hnw', label: 'US$2 Million – US$10 Million', desc: 'Strategic global asset allocation, offshore trusts, custom tax strategy.' },
                      { id: 'uhnw', label: 'US$10 Million+', desc: 'Complex multi-family solutions, direct venture deals, private legal governance.' },
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        onClick={() => setAssets(opt.id)}
                        className={`w-full p-4 rounded text-left border transition-all hover:bg-white/[0.02] cursor-pointer ${
                          assets === opt.id ? 'border-white bg-white/[0.03]' : 'border-white/10 bg-transparent'
                        }`}
                      >
                        <span className="font-serif text-sm block font-medium mb-1">{opt.label}</span>
                        <span className="text-xs text-white/40 font-light block">{opt.desc}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Step 3: Location */}
              {step === 3 && (
                <motion.div
                  key="step-3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center space-y-2 mb-6">
                    <h3 className="text-xl font-serif text-white">Where is your primary domicile?</h3>
                    <p className="text-xs text-white/50">Choosing your region ensures regulatory alignment and direct access.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-3 max-w-lg mx-auto">
                    {[
                      { id: 'sa', label: 'South Africa (Local Services)', desc: 'Full wealth integration aligned with local SARS requirements and SARB exchange.' },
                      { id: 'intl', label: 'Offshore / International (Dual Domicile)', desc: 'Multi-jurisdictional structures, UK/EU integration, offshore asset trust plans.' },
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        onClick={() => setLocation(opt.id)}
                        className={`w-full p-4 rounded text-left border transition-all hover:bg-white/[0.02] cursor-pointer ${
                          location === opt.id ? 'border-white bg-white/[0.03]' : 'border-white/10 bg-transparent'
                        }`}
                      >
                        <span className="font-serif text-sm block font-medium mb-1">{opt.label}</span>
                        <span className="text-xs text-white/40 font-light block">{opt.desc}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Step 4: Result matched partner */}
              {step === 4 && matchedPartner && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="space-y-6 max-w-xl mx-auto"
                >
                  <div className="text-center space-y-1 mb-4">
                    <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-green-400 uppercase">
                      Advisor Match Found
                    </span>
                    <h3 className="text-2xl font-serif text-white">Your Matched Corient Elite Partner</h3>
                  </div>

                  {/* Partner Card */}
                  <div className="bg-[#111a22] rounded-lg border border-white/5 overflow-hidden flex flex-col md:flex-row items-center md:items-stretch shadow-2xl">
                    <div className="w-full md:w-2/5 min-h-[220px] relative">
                      <img
                        src={matchedPartner.photo}
                        alt={matchedPartner.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="text-xl font-serif text-white font-medium mb-1">{matchedPartner.name}</h4>
                        <p className="text-xs text-white/50 font-sans tracking-wide mb-4 font-medium uppercase">{matchedPartner.role}</p>
                        
                        <p className="text-xs text-white/70 font-light leading-relaxed mb-4 italic">
                          "{matchedPartner.bio}"
                        </p>

                        <div className="space-y-2 border-t border-white/5 pt-3">
                          <div className="flex items-center gap-2 text-xs text-white/60">
                            <MapPin size={12} className="text-white/30" />
                            <span>{matchedPartner.location}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-white/60">
                            <Briefcase size={12} className="text-white/30" />
                            <span>Specialties: {matchedPartner.specialty.join(', ')}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-4">
                    <button
                      id="matcher-connect-btn"
                      onClick={() => {
                        onSelectPartner(matchedPartner.name);
                        onClose();
                      }}
                      className="flex-1 py-3.5 bg-white text-black font-sans font-semibold text-xs tracking-widest rounded hover:bg-black hover:text-white border hover:border-white border-transparent transition-all duration-300 uppercase cursor-pointer"
                    >
                      Connect with {matchedPartner.name}
                    </button>
                    <button
                      id="matcher-restart-btn"
                      onClick={handleReset}
                      className="px-6 py-3.5 border border-white/10 hover:border-white/40 text-xs font-semibold tracking-widest uppercase transition-colors rounded cursor-pointer"
                    >
                      Restart Matcher
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Bottom Actions for Wizard Navigation */}
          {step < 4 && (
            <div className="px-6 py-4 border-t border-white/5 bg-[#070b0e] flex items-center justify-between">
              <button
                id="matcher-back-btn"
                onClick={handleBack}
                disabled={step === 1}
                className="flex items-center gap-1.5 text-xs font-medium tracking-wider text-white/40 hover:text-white disabled:opacity-0 transition-opacity uppercase cursor-pointer py-1.5"
              >
                <ChevronLeft size={14} />
                <span>Back</span>
              </button>
              <button
                id="matcher-next-btn"
                onClick={handleNext}
                disabled={
                  (step === 1 && !goal) ||
                  (step === 2 && !assets) ||
                  (step === 3 && !location)
                }
                className="flex items-center gap-1 bg-white text-black hover:bg-white/80 px-5 py-2.5 rounded font-sans font-semibold text-[11px] tracking-wider uppercase transition-colors disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
              >
                <span>Continue</span>
                <ChevronRight size={14} />
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
