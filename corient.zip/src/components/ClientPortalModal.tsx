/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Lock, Key, LineChart, TrendingUp, ShieldCheck, Wallet, ArrowUpRight } from 'lucide-react';

interface ClientPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ClientPortalModal({ isOpen, onClose }: ClientPortalModalProps) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('portfolio@corient.com');
  const [password, setPassword] = useState('••••••••');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsLoggedIn(true);
      setIsSubmitting(false);
    }, 1200);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('portfolio@corient.com');
    setPassword('••••••••');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-md transition-opacity"
      />

      {/* Center Modal */}
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="w-full max-w-lg bg-[#090f14] border border-white/5 text-white rounded-xl shadow-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-white/5 flex items-center justify-between bg-black/20">
            <h3 className="text-sm font-serif tracking-widest text-white/90 flex items-center gap-2 uppercase">
              <Lock size={14} className="text-white/40" />
              <span>Corient Secure Portal</span>
            </h3>
            <button
              id="portal-close-btn"
              onClick={onClose}
              className="p-2 -mr-2 hover:bg-white/5 rounded-full transition-colors text-white"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>

          <AnimatePresence mode="wait">
            {!isLoggedIn ? (
              /* LOGIN FORM */
              <motion.form
                key="login-form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onSubmit={handleLogin}
                className="p-6 md:p-8 space-y-5"
              >
                <div className="text-center space-y-2 mb-4">
                  <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">
                    Authorized Access Only
                  </span>
                  <h4 className="text-xl font-serif text-white font-light">Enter Wealth Credentials</h4>
                </div>

                {/* Email */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-semibold tracking-wider text-white/40 uppercase">
                    Username or Account Email
                  </label>
                  <div className="relative">
                    <input
                      required
                      type="email"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full bg-[#111a22] text-white pl-4 pr-10 py-3 rounded border border-white/5 focus:border-white/20 outline-none text-sm font-light transition-all"
                    />
                    <Key className="absolute right-3 top-1/2 -translate-y-1/2 text-white/20" size={16} />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-semibold tracking-wider text-white/40 uppercase">
                      Access Key / Password
                    </label>
                    <span className="text-[10px] text-white/30 hover:text-white/60 hover:underline cursor-pointer">
                      Forgot?
                    </span>
                  </div>
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#111a22] text-white px-4 py-3 rounded border border-white/5 focus:border-white/20 outline-none text-sm font-light transition-all"
                  />
                </div>

                {/* Notice */}
                <p className="text-[10px] text-white/30 leading-relaxed font-light">
                  By clicking "Authenticate", you agree to our multi-factor identity authorization guidelines. Secure cookies are required to manage your private session.
                </p>

                {/* Submit */}
                <button
                  id="authenticate-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-white text-black hover:bg-black hover:text-white border border-transparent hover:border-white text-xs font-semibold tracking-widest rounded transition-all duration-300 uppercase flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'Authenticating...' : 'Authenticate Credentials'}
                </button>
              </motion.form>
            ) : (
              /* SIMULATED CLIENT DASHBOARD */
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="p-6 md:p-8 space-y-6"
              >
                {/* Account Owner Card */}
                <div className="flex items-center justify-between border-b border-white/5 pb-4">
                  <div>
                    <span className="text-[10px] font-semibold tracking-wider text-green-400 uppercase flex items-center gap-1">
                      <ShieldCheck size={12} />
                      <span>Encrypted Connection Active</span>
                    </span>
                    <h4 className="text-lg font-serif text-white font-medium mt-1">Portfolio: Sterling Trust</h4>
                  </div>
                  <button
                    id="logout-btn"
                    onClick={handleLogout}
                    className="text-[10px] font-semibold tracking-wider border border-white/10 hover:border-white/30 text-white/50 hover:text-white px-3 py-1.5 rounded transition-all uppercase cursor-pointer"
                  >
                    Disconnect
                  </button>
                </div>

                {/* Account Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-[#111a22] rounded p-4 border border-white/5">
                    <span className="text-[10px] text-white/40 font-semibold tracking-wider block uppercase">Consolidated Net Worth</span>
                    <span className="text-xl sm:text-2xl font-serif text-white font-medium block mt-1">US$4,291,520</span>
                    <span className="text-[10px] text-green-400 font-medium flex items-center gap-1 mt-1">
                      <TrendingUp size={10} />
                      <span>+8.42% Year-to-Date</span>
                    </span>
                  </div>
                  <div className="bg-[#111a22] rounded p-4 border border-white/5">
                    <span className="text-[10px] text-white/40 font-semibold tracking-wider block uppercase">Sovereign Cash Reserves</span>
                    <span className="text-xl sm:text-2xl font-serif text-white font-medium block mt-1">US$342,000</span>
                    <span className="text-[10px] text-white/40 font-medium block mt-1">Yielding 4.85% APY</span>
                  </div>
                </div>

                {/* Simulated Allocation Bar Chart */}
                <div className="space-y-2">
                  <span className="text-[10px] text-white/40 font-semibold tracking-wider block uppercase">Asset Distribution</span>
                  <div className="h-6 w-full rounded overflow-hidden flex text-[10px] font-semibold">
                    <div className="bg-blue-500 h-full flex items-center justify-center text-white" style={{ width: '45%' }} title="Global Equities">45%</div>
                    <div className="bg-emerald-500 h-full flex items-center justify-center text-white" style={{ width: '25%' }} title="Alternative Funds">25%</div>
                    <div className="bg-amber-500 h-full flex items-center justify-center text-white" style={{ width: '15%' }} title="Fixed Income">15%</div>
                    <div className="bg-indigo-500 h-full flex items-center justify-center text-white" style={{ width: '15%' }} title="Real Estate">15%</div>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-white/50">
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-500" />Global Equities</span>
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />Alternatives</span>
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-amber-500" />Fixed Income</span>
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />Liquid Estate</span>
                  </div>
                </div>

                {/* Connected Advisor */}
                <div className="p-4 bg-white/[0.02] border border-white/5 rounded flex items-center gap-3">
                  <img
                    src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80"
                    alt="Evelyn Sterling"
                    className="w-10 h-10 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <span className="text-[9px] text-white/40 font-semibold tracking-wider uppercase">Direct Fiduciary Advisor</span>
                    <h5 className="text-sm font-serif font-medium text-white truncate">Evelyn Sterling</h5>
                  </div>
                  <a
                    href="mailto:e.sterling@corient.co.za"
                    className="text-[10px] font-semibold text-white hover:underline uppercase tracking-wider flex items-center gap-1"
                  >
                    <span>Secure Email</span>
                    <ArrowUpRight size={10} />
                  </a>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}
