/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Check, ArrowRight, Lightbulb, Compass, HeartHandshake } from 'lucide-react';

interface SolutionsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onContactClick: () => void;
}

const solutions = [
  {
    title: 'High-Net-Worth Advisory',
    subtitle: 'Capital preservation & growth',
    icon: Compass,
    highlights: [
      'Tailored portfolio risk allocation models',
      'Advanced global asset cross-border diversification',
      'Exclusive access to vetted alternative private equity',
      'Dynamic tax optimization frameworks',
    ],
    desc: 'Custom solutions for individuals and families with investable assets between US$2M and US$25M. We focus on securing stable long-term growth while hedging against localized currency risks and inflationary pressures.',
  },
  {
    title: 'Business Owner Succession',
    subtitle: 'Unlocking and protecting enterprise value',
    icon: Lightbulb,
    highlights: [
      'Corporate structure capitalization tuning',
      'Pre-transaction tax optimization plans',
      'Sovereign state liquidity preservation strategies',
      'Generational business succession governance',
    ],
    desc: 'For founders and partners intending to scale, recapitalize, or exit their enterprises. We help bridge the gap between corporate balance sheets and private family estate structures, ensuring a seamless liquidity transition.',
  },
  {
    title: 'Ultra-High-Net-Worth Office',
    subtitle: 'Institutional-grade stewardship',
    icon: HeartHandshake,
    highlights: [
      'Bespoke sovereign wealth and trust frameworks',
      'Aircraft, maritime, and luxury real estate logistics',
      'Direct seed venture deals and co-investment access',
      'Consolidated multi-custody global reporting systems',
    ],
    desc: 'For multi-family offices, foundations, and individuals with investable capitals exceeding US$50M. We deliver highly customized institutional concierge structures, ensuring rigorous asset protection, succession, and governance.',
  },
];

export default function SolutionsPanel({ isOpen, onClose, onContactClick }: SolutionsPanelProps) {
  const [activeIdx, setActiveIdx] = useState(0);

  if (!isOpen) return null;

  const ActiveIcon = solutions[activeIdx].icon;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-xs transition-opacity"
      />

      {/* Slide-in Overly from Right */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 180 }}
          className="w-screen max-w-3xl bg-[#090f14] text-white flex flex-col justify-between shadow-2xl border-l border-white/5"
        >
          {/* Header */}
          <div className="px-6 py-6 border-b border-white/5 flex items-center justify-between">
            <span className="text-xs font-sans font-semibold tracking-[0.25em] text-white/40 uppercase">
              Strategic Solutions
            </span>
            <button
              id="solutions-close-btn"
              onClick={onClose}
              className="p-2 -mr-2 hover:bg-white/5 rounded-full transition-colors text-white"
              aria-label="Close"
            >
              <X size={20} />
            </button>
          </div>

          {/* Scrollable Content Body */}
          <div className="flex-1 overflow-y-auto px-6 py-8 md:px-10 flex flex-col md:flex-row gap-8">
            {/* Left side column: Menu */}
            <div className="w-full md:w-2/5 space-y-2">
              <h2 className="text-2xl font-serif text-white tracking-wide mb-6">Explore Solutions</h2>
              {solutions.map((sol, sIdx) => {
                const isSelected = sIdx === activeIdx;
                return (
                  <button
                    key={sol.title}
                    id={`sol-nav-btn-${sIdx}`}
                    onClick={() => setActiveIdx(sIdx)}
                    className={`w-full p-4 rounded text-left border transition-all duration-300 flex items-start gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-[#111a22] border-white text-white shadow-md'
                        : 'bg-transparent border-white/5 hover:border-white/25 text-white/50 hover:text-white/80'
                    }`}
                  >
                    <div>
                      <span className="text-sm font-serif font-medium block">{sol.title}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Right side column: Detail Pane */}
            <div className="flex-1 bg-[#111a22]/60 rounded-xl border border-white/5 p-6 md:p-8 flex flex-col justify-between min-h-[350px]">
              <div>
                <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center mb-6 border border-white/10 text-white">
                  <ActiveIcon size={24} className="stroke-[1.5]" />
                </div>

                <h3 className="text-2xl font-serif text-white mb-1 tracking-wide">{solutions[activeIdx].title}</h3>
                <p className="text-xs text-white/40 tracking-wider font-semibold uppercase mb-4">{solutions[activeIdx].subtitle}</p>

                <p className="text-sm text-white/70 font-light leading-relaxed mb-6">
                  {solutions[activeIdx].desc}
                </p>

                {/* Highlights List */}
                <div className="space-y-2 border-t border-white/5 pt-4">
                  <span className="text-[10px] font-sans font-semibold tracking-wider text-white/40 block uppercase mb-2">
                    Key Features
                  </span>
                  {solutions[activeIdx].highlights.map((hl) => (
                    <div key={hl} className="flex items-start gap-2 text-xs text-white/80">
                      <Check size={14} className="text-green-400 shrink-0 mt-0.5" />
                      <span>{hl}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-8 border-t border-white/5 mt-8 flex justify-end">
                <button
                  id={`sol-action-btn-${activeIdx}`}
                  onClick={() => {
                    onClose();
                    onContactClick();
                  }}
                  className="flex items-center gap-2 group text-xs font-semibold tracking-widest text-white hover:opacity-80 transition-opacity uppercase cursor-pointer"
                >
                  <span>Request Custom Strategy Plan</span>
                  <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>

          {/* Bottom Callout */}
          <div className="px-6 py-6 border-t border-white/5 bg-[#070b0e] text-center">
            <p className="text-xs text-white/50 font-light">
              Collaboratively structured to remove typical advisory conflicts.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
