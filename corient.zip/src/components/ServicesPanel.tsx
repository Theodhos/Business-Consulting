/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Shield, BarChart3, Users, KeyRound, ArrowRight } from 'lucide-react';

interface ServicesPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onContactClick: () => void;
}

const services = [
  {
    icon: Shield,
    title: 'Family Office Services',
    subtitle: 'Comprehensive multi-generational administration',
    desc: 'Our family office suite acts as your dedicated institutional management arm. We supervise global consolidated accounting, private lifestyle management, aircraft or yacht leasing structure, tax structuring, multi-family legal setups, and legacy foundations.',
  },
  {
    icon: BarChart3,
    title: 'Wealth Strategy',
    subtitle: 'Goal-aligned investment and strategy architecture',
    desc: 'A meticulously personalized plan built for wealth growth, wealth reservation, and asset hedging. We supervise customized model portfolios, structured fixed income, risk assessment matrices, currency hedging, and absolute return alternative setups.',
  },
  {
    icon: Users,
    title: 'Trust & Estate Planning',
    subtitle: 'Securing multi-generational heritage legacies',
    desc: 'Structured fiduciary strategies designed to handle sovereign jurisdictions and cross-border assets. We structure custom offshore/local trusts, charitable giving plans, generational wealth transfers, and coordinate estate probate minimization.',
  },
  {
    icon: KeyRound,
    title: 'Corporate Advisory',
    subtitle: 'Structuring succession and business liquidity',
    desc: 'Bespoke guidance for business founders, private equity directors, and corporate leaders. We supervise private placements, corporate liquidity strategy, tax optimization on corporate sales, and business succession roadmap structures.',
  },
];

export default function ServicesPanel({ isOpen, onClose, onContactClick }: ServicesPanelProps) {
  const [activeIdx, setActiveIdx] = useState(0);

  if (!isOpen) return null;

  const ActiveIcon = services[activeIdx].icon;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-xs transition-opacity"
      />

      {/* Slide-in Overly from Right */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 180 }}
          className="w-screen max-w-3xl bg-[#090f14] text-white flex flex-col justify-between shadow-2xl border-l border-white/5"
        >
          {/* Header */}
          <div className="px-6 py-6 border-b border-white/5 flex items-center justify-between">
            <span className="text-xs font-sans font-semibold tracking-[0.25em] text-white/40 uppercase">
              Our Capabilities
            </span>
            <button
              id="services-close-btn"
              onClick={onClose}
              className="p-2 -mr-2 hover:bg-white/5 rounded-full transition-colors text-white"
              aria-label="Close"
            >
              <X size={20} />
            </button>
          </div>

          {/* Scrollable Content Body */}
          <div className="flex-1 overflow-y-auto px-6 py-8 md:px-10 flex flex-col md:flex-row gap-8">
            {/* Left side column: Menu */}
            <div className="w-full md:w-2/5 space-y-2">
              <h2 className="text-2xl font-serif text-white tracking-wide mb-6">Discover Services</h2>
              {services.map((svc, sIdx) => {
                const isSelected = sIdx === activeIdx;
                const IconComp = svc.icon;
                return (
                  <button
                    key={svc.title}
                    id={`service-nav-btn-${sIdx}`}
                    onClick={() => setActiveIdx(sIdx)}
                    className={`w-full p-4 rounded text-left border transition-all duration-300 flex items-start gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-[#111a22] border-white text-white shadow-md'
                        : 'bg-transparent border-white/5 hover:border-white/25 text-white/50 hover:text-white/80'
                    }`}
                  >
                    <IconComp size={18} className={`shrink-0 mt-0.5 ${isSelected ? 'text-white' : 'text-white/30'}`} />
                    <div>
                      <span className="text-sm font-serif font-medium block">{svc.title}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Right side column: Detail Pane */}
            <div className="flex-1 bg-[#111a22]/60 rounded-xl border border-white/5 p-6 md:p-8 flex flex-col justify-between min-h-[350px]">
              <div>
                <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center mb-6 border border-white/10 text-white">
                  <ActiveIcon size={24} className="stroke-[1.5]" />
                </div>

                <h3 className="text-2xl font-serif text-white mb-1 tracking-wide">{services[activeIdx].title}</h3>
                <p className="text-xs text-white/40 tracking-wider font-semibold uppercase mb-6">{services[activeIdx].subtitle}</p>

                <p className="text-sm text-white/70 font-light leading-relaxed">
                  {services[activeIdx].desc}
                </p>
              </div>

              <div className="pt-8 border-t border-white/5 mt-8 flex justify-end">
                <button
                  id={`service-action-btn-${activeIdx}`}
                  onClick={() => {
                    onClose();
                    onContactClick();
                  }}
                  className="flex items-center gap-2 group text-xs font-semibold tracking-widest text-white hover:opacity-80 transition-opacity uppercase cursor-pointer"
                >
                  <span>Inquire About Service</span>
                  <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>

          {/* Bottom Callout */}
          <div className="px-6 py-6 border-t border-white/5 bg-[#070b0e] text-center">
            <p className="text-xs text-white/50 font-light">
              We operate exclusively under fiduciary standard to always put our client's interest first.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
