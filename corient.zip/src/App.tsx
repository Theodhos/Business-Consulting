/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import Navbar from './components/Navbar';
import HeroSlider from './components/HeroSlider';
import MenuDrawer from './components/MenuDrawer';
import ContactDrawer from './components/ContactDrawer';
import PartnerMatcher from './components/PartnerMatcher';
import ServicesPanel from './components/ServicesPanel';
import SolutionsPanel from './components/SolutionsPanel';
import ClientPortalModal from './components/ClientPortalModal';
import Footer from './components/Footer';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isMatcherOpen, setIsMatcherOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isSolutionsOpen, setIsSolutionsOpen] = useState(false);
  const [isPortalOpen, setIsPortalOpen] = useState(false);
  const [contactPrefill, setContactPrefill] = useState('');

  const handleActionClick = (type: 'services' | 'solutions' | 'partner') => {
    if (type === 'services') {
      setIsServicesOpen(true);
    } else if (type === 'solutions') {
      setIsSolutionsOpen(true);
    } else if (type === 'partner') {
      setIsMatcherOpen(true);
    }
  };

  const handleMenuNavigate = (section: 'services' | 'solutions' | 'partner' | 'contact' | 'home' | 'about') => {
    if (section === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (section === 'services') {
      setIsServicesOpen(true);
    } else if (section === 'solutions') {
      setIsSolutionsOpen(true);
    } else if (section === 'partner') {
      setIsMatcherOpen(true);
    } else if (section === 'contact') {
      setContactPrefill('');
      setIsContactOpen(true);
    }
  };

  const handlePartnerSelected = (partnerName: string) => {
    setContactPrefill(`Dear Corient Advisors,\n\nI was matched with your elite partner, ${partnerName}, and would love to arrange a confidential, direct wealth consultation to discuss our asset management needs.`);
    setIsContactOpen(true);
  };

  const handleFooterLinkClick = (section: 'services' | 'solutions' | 'partner' | 'contact') => {
    if (section === 'services') {
      setIsServicesOpen(true);
    } else if (section === 'solutions') {
      setIsSolutionsOpen(true);
    } else if (section === 'partner') {
      setIsMatcherOpen(true);
    } else if (section === 'contact') {
      setContactPrefill('');
      setIsContactOpen(true);
    }
  };

  return (
    <div className="bg-[#05090c] text-white min-h-screen relative selection:bg-white selection:text-black">
      {/* 1. Header Navbar */}
      <Navbar
        onMenuClick={() => setIsMenuOpen(true)}
        onMeetPartnerClick={() => setIsMatcherOpen(true)}
        onNavigate={handleMenuNavigate}
        onPartnerSelect={handlePartnerSelected}
      />

      {/* 2. Primary Hero Slideshow Section (Covers first 3 screenshots) */}
      <main className="relative">
        <HeroSlider onActionClick={handleActionClick} />

        {/* 3. Middle "Speak to a Partner / Contact Us" Section (Covers screenshot 4) */}
        <section className="bg-gradient-to-b from-[#090f14] to-[#05090c] py-24 border-t border-white/5 flex flex-col justify-center items-center text-center px-6 relative z-10">
          {/* Vertical white/grey elegant line leading from above */}
          <div className="w-[1.5px] h-20 bg-gradient-to-b from-white/30 to-transparent mb-10" />

          <div className="max-w-2xl mx-auto space-y-6">
            <span className="text-xs font-sans font-light tracking-[0.25em] text-white/50 uppercase block">
              Continue Your Journey
            </span>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light tracking-wide text-white leading-tight">
              Speak to a Partner
            </h2>

            <div className="pt-6">
              <button
                id="cta-contact-us-btn"
                onClick={() => {
                  setContactPrefill('');
                  setIsContactOpen(true);
                }}
                className="px-10 py-4 bg-white text-black font-sans font-medium text-xs md:text-sm tracking-widest rounded-full hover:bg-black hover:text-white border border-white hover:border-white transition-all duration-300 shadow-xl hover:shadow-2xl cursor-pointer uppercase"
              >
                Contact Us
              </button>
            </div>
          </div>
        </section>

        {/* 4. Complete Footer Section (Covers screenshot 5) */}
        <Footer
          onLinkClick={handleFooterLinkClick}
          onClientPortalClick={() => setIsPortalOpen(true)}
        />
      </main>

      {/* 5. Animated Interactive Drawers and Overlays */}
      <AnimatePresence>
        {/* Navigation Sidebar Drawer */}
        {isMenuOpen && (
          <MenuDrawer
            isOpen={isMenuOpen}
            onClose={() => setIsMenuOpen(false)}
            onNavigate={handleMenuNavigate}
          />
        )}

        {/* Contact Form Drawer */}
        {isContactOpen && (
          <ContactDrawer
            isOpen={isContactOpen}
            onClose={() => setIsContactOpen(false)}
            prefilledMessage={contactPrefill}
          />
        )}

        {/* Intelligent Partner Matcher Questionnaire */}
        {isMatcherOpen && (
          <PartnerMatcher
            isOpen={isMatcherOpen}
            onClose={() => setIsMatcherOpen(false)}
            onSelectPartner={handlePartnerSelected}
          />
        )}

        {/* Wealth Services Showcase Panel */}
        {isServicesOpen && (
          <ServicesPanel
            isOpen={isServicesOpen}
            onClose={() => setIsServicesOpen(false)}
            onContactClick={() => setIsContactOpen(true)}
          />
        )}

        {/* Tailored Case Studies and Solutions Panel */}
        {isSolutionsOpen && (
          <SolutionsPanel
            isOpen={isSolutionsOpen}
            onClose={() => setIsSolutionsOpen(false)}
            onContactClick={() => setIsContactOpen(true)}
          />
        )}

        {/* Simulated Authorized Client Portal Modal */}
        {isPortalOpen && (
          <ClientPortalModal
            isOpen={isPortalOpen}
            onClose={() => setIsPortalOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
