/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Stat {
  value: string;
  label: string;
}

export interface Slide {
  id: number;
  image: string;
  title: string;
  subtitle: string;
  buttonText: string;
  stats?: Stat[];
  actionType: 'services' | 'solutions' | 'partner';
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  createdAt: string;
}

export interface Partner {
  id: string;
  name: string;
  role: string;
  photo: string;
  specialty: string[];
  bio: string;
  location: string;
  experience: string;
}
